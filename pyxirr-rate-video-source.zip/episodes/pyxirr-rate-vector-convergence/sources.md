Source ledger — reviewed before narration

Report: https://www.gero.uz/research/articles/pyxirr-rate-vector-convergence.html
Evidence archive: https://www.gero.uz/research/data/pyxirr-rate/gero-pyxirr-rate-evidence-2026-09-13.zip
Public artifact: https://www.gero.uz/research/data/pyxirr-rate/gero-pyxirr-rate-evidence-2026-09-13.zip
Primary sources:
https://github.com/Anexen/pyxirr/blob/5f31a85684051fb6badb542afba0ac1af5a68f9c/src/core/periodic.rs
https://anexen.github.io/pyxirr/functions.html#rate

Scene 1: With a fifty-percent starting guess, this financial library returned thirteen point five eight percent per period for a synthetic loan.
Classification: Directly verified released-wheel and native Rust results from the 13 September 2026 GERO investigation; all inputs are synthetic.

Scene 2: Two hundred thousand borrowed. Three hundred sixty payments of one thousand. Direct discounting gives about zero point three six six percent per period.
Classification: Directly verified released-wheel and native Rust results from the 13 September 2026 GERO investigation; all inputs are synthetic.

Scene 3: The array solver had not converged. Its final check ignored large negative steps. The correction returns failure here, and a second fix stabilizes calculations around zero.
Classification: Directly verified released-wheel and native Rust results from the 13 September 2026 GERO investigation; all inputs are synthetic.

Scene 4: The corrected Rust code passed two hundred forty-two tests and four hundred nine extra checks. The report includes code and limitations. No customer losses were measured.
Classification: Directly verified released-wheel and native Rust results from the 13 September 2026 GERO investigation; all inputs are synthetic.

Narration client: https://github.com/rany2/edge-tts . The client is open source; synthesis uses Microsoft's online service, not an open local model. Only reviewed public narration text was submitted.

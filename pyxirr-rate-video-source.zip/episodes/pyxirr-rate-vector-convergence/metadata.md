When a returned interest rate has not converged

Two verified defects in the vectorized periodic RATE solver: a signed convergence check and unstable zero/near-zero arithmetic.

Report: https://www.gero.uz/research/articles/pyxirr-rate-vector-convergence.html
Evidence archive: https://www.gero.uz/research/data/pyxirr-rate/gero-pyxirr-rate-evidence-2026-09-13.zip
Public artifact: https://www.gero.uz/research/data/pyxirr-rate/gero-pyxirr-rate-evidence-2026-09-13.zip
Primary sources:
https://github.com/Anexen/pyxirr/blob/5f31a85684051fb6badb542afba0ac1af5a68f9c/src/core/periodic.rs
https://anexen.github.io/pyxirr/functions.html#rate

The main example explicitly uses a 50% starting guess. The true rate is 0.3655927952% per payment period; the unfinished vector iterate is 13.5844084693%. The candidate rejects that unfinished solve instead of returning the true root from this guess. Other near-zero examples are corrected. Tests do not establish production exposure or customer losses. The candidate has not been accepted upstream.

Research and editorial review: Xamit Kadirbekov / GERO Research. Independent work; no affiliation with the organizations discussed.
Narration: synthetic English preset Microsoft Andrew Neural via edge-tts. Alex Vector is a fictional narrator. Original diagrams; AI-assisted preparation.

#Fintech #SoftwareTesting #NumericalStability #OpenSource #GERO

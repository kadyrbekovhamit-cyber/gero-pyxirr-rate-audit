With a fifty-percent starting guess, this financial library returned thirteen point five eight percent per period for a synthetic loan.

Two hundred thousand borrowed. Three hundred sixty payments of one thousand. Direct discounting gives about zero point three six six percent per period.

The array solver had not converged. Its final check ignored large negative steps. The correction returns failure here, and a second fix stabilizes calculations around zero.

The corrected Rust code passed two hundred forty-two tests and four hundred nine extra checks. The report includes code and limitations. No customer losses were measured.

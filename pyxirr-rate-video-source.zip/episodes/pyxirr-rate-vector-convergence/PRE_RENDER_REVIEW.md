Reviewed before synthesis on 13 September 2026.

All four scenes use the verified synthetic inputs and measured results in ../fintech-invariant-hunt/REPORT.md and PROVENANCE.json. The starting guess, period units, nonconvergence-vs-correction distinction, candidate status, and absence of measured customer losses are retained. The native and extra check counts are 242 and 255+154=409. No model-based or production accuracy claim. Original diagrams and preset synthetic English narration; no cloned identity, music or third-party footage.

Style reference: user-named Ingenium concept thread, Microsoft online speech via edge-tts. English GERO voice: en-US-AndrewNeural, -3%. Only this public script is transmitted for synthesis. Current user instruction authorizes the narrated video and publication.

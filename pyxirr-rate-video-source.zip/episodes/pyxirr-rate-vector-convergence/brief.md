English portrait explainer for Technology Product.
Audience: engineers and readers of GERO research.
Narrator: fictional Alex Vector; preset Microsoft en-US-AndrewNeural, edge-tts 7.2.8, rate -3%.
Original evidence diagrams; no third-party footage or music.
Evidence category: audit.
The main example explicitly uses a 50% starting guess. The true rate is 0.3655927952% per payment period; the unfinished vector iterate is 13.5844084693%. The candidate rejects that unfinished solve instead of returning the true root from this guess. Other near-zero examples are corrected. Tests do not establish production exposure or customer losses. The candidate has not been accepted upstream.

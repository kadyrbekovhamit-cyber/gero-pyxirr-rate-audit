"""Original portrait evidence cards. One FFmpeg encoder/filter worker, CPU only.

Caption timing uses actual WordBoundary events returned with the narration,
not guessed reading durations. This is not Whisper transcription.
"""
import argparse, hashlib, html, json, re, shutil, subprocess, textwrap
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
FONT='/System/Library/Fonts/Supplemental/Arial.ttf'
BOLD='/System/Library/Fonts/Supplemental/Arial Bold.ttf'
BG='#101923';INK='#F4F7F9';ACC='#68E4CD';MUT='#AAB8C6';AMBER='#F2C77C'
def run(args):
    result=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,timeout=180)
    if result.returncode:raise RuntimeError(result.stderr[-4000:])
    return result.stdout
def duration(path):
    return float(run(['ffprobe','-v','error','-show_entries','format=duration','-of','csv=p=0',str(path)]).strip())
def block(d,text,x,y,size,color=INK,bold=False,width=568,bottom=1200,gap=1.18):
    font=ImageFont.truetype(BOLD if bold else FONT,size)
    for para in text.split('\n'):
        line=''
        lines=[]
        for word in para.split():
            trial=(line+' '+word).strip()
            if d.textlength(trial,font=font)>width and line:lines.append(line);line=word
            else:line=trial
        lines.append(line)
        for line in lines:
            assert d.textlength(line,font=font)<=width,(text,line)
            assert y+size*gap<=bottom,(text,y,size,bottom)
            d.text((x,y),line,font=font,fill=color);y+=round(size*gap)
    return y
def stamp(t,ass=False):
    units=100 if ass else 1000
    whole=round(t*units);h,whole=divmod(whole,3600*units);m,whole=divmod(whole,60*units);s,part=divmod(whole,units)
    return f'{h}:{m:02}:{s:02}.{part:02}' if ass else f'{h:02}:{m:02}:{s:02},{part:03}'
def caption_groups(events,original):
    # Restore punctuation from the authored transcript without changing timing.
    annotated=[];cursor=0
    for event in events:
        event=dict(event);word=html.unescape(event['text'])
        found=original.lower().find(word.lower(),cursor)
        if found>=0:
            cursor=found+len(word)
            suffix=re.match(r'[,.;:!?]*',original[cursor:]).group(0)
            event['text']=word+suffix
        annotated.append(event)
    groups=[];current=[]
    for event in annotated:
        current.append(event)
        words=' '.join(x['text'] for x in current)
        if len(current)>=6 or len(words)>36 or words.endswith(('.', '?', '!')):
            groups.append(current);current=[]
    if current:groups.append(current)
    return [(g[0]['offset']/1e7,(g[-1]['offset']+g[-1]['duration'])/1e7,html.unescape(' '.join(x['text'] for x in g))) for g in groups]
ASS='''[Script Info]
ScriptType: v4.00+
PlayResX: 720
PlayResY: 1280
WrapStyle: 0
[V4+ Styles]
Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding
Style: Default,Arial,31,&H00F4F7F9,&H00F4F7F9,&H00101923,&H00101923,0,0,0,0,100,100,0,0,1,1,0,5,76,100,0,1
[Events]
Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text
'''
def main():
    parser=argparse.ArgumentParser();parser.add_argument('--slug');args=parser.parse_args()
    catalogue={x['slug'].removesuffix('.html'):x for x in json.loads((ROOT/'catalog-baseline.json').read_text())['publications']}
    if (ROOT/'supplemental-catalogue.json').exists():
        catalogue.update({x['slug'].removesuffix('.html'):x for x in json.loads((ROOT/'supplemental-catalogue.json').read_text())})
    for e in json.loads((ROOT/'episodes.json').read_text()):
        if args.slug and args.slug!=e['slug']:continue
        p=ROOT/'episodes'/e['slug'];a=p/'assets';out=p/'output';out.mkdir(parents=True,exist_ok=True)
        signature=hashlib.sha256(json.dumps(e,sort_keys=True).encode()+Path(__file__).read_bytes()).hexdigest()
        if (out/'render.json').exists() and json.loads((out/'render.json').read_text()).get('signature')==signature:
            print('CACHED RENDER',e['slug'],flush=True);continue
        allcues=[];total=0;segments=[];story=[]
        for i,scene in enumerate(e['scenes'],1):
            narration=a/f'narration-{i}.mp3';record=json.loads((a/f'narration-{i}.json').read_text())
            assert record['text']==scene['voice']
            length=duration(narration)+0.25
            im=Image.new('RGB',(720,1280),BG);d=ImageDraw.Draw(im)
            d.rectangle((0,0,8,1280),fill=ACC)
            block(d,'GERO  /  TECHNOLOGY PRODUCT',64,74,21,ACC,True,width=580,bottom=120)
            block(d,e['category'],64,126,18,MUT,width=550,bottom=185)
            block(d,scene['title'],64,214,47,bold=True,bottom=418)
            d.rounded_rectangle((48,438,654,815),radius=24,fill='#1B2A38',outline='#334956',width=2)
            block(d,scene['label'],72,465,18,AMBER,True,width=545,bottom=536)
            block(d,scene['display'],72,570,32,ACC,True,width=540,bottom=793,gap=1.35)
            d.line((64,873,640,873),fill='#334956',width=2)
            footer='PUBLIC REPORT + REPRODUCER  ·  GERO.UZ' if e.get('kind','audit')=='audit' else 'SOURCE + EVIDENCE BOUNDARY  ·  GERO.UZ'
            block(d,footer,64,1090,18,MUT,width=580,bottom=1130)
            block(d,f'{i:02} / {len(e["scenes"]):02}     Original diagrams · Synthetic English narration',64,1144,16,MUT,width=580,bottom=1200)
            for j in range(len(e['scenes'])):d.rounded_rectangle((64+j*144,1224,190+j*144,1229),radius=2,fill=ACC if j<i else '#334956')
            frame=a/f'card-{i}.png';im.save(frame)
            cues=caption_groups(record['events'],scene['voice'])
            # Encode only changes between caption cards. Timestamps come from the
            # service's word events; no libass or high-frame-rate rendering needed.
            timed_frames=[];last=0
            for k,(start,end,text) in enumerate(cues):
                start=max(last,start);end=min(length,end)
                if start>last:timed_frames.append((frame,start-last))
                caption=im.copy();cd=ImageDraw.Draw(caption)
                block(cd,text,76,928,31,INK,width=550,bottom=1050)
                caption_path=a/f'caption-{i}-{k}.png';caption.save(caption_path)
                if end>start:timed_frames.append((caption_path,end-start))
                last=end
            if length>last:timed_frames.append((frame,length-last))
            frames=a/f'frames-{i}.txt'
            frames.write_text(''.join("file '"+str(f)+"'\nduration "+f'{seconds:.7f}'+'\n' for f,seconds in timed_frames)+"file '"+str(frame)+"'\n")
            segment=a/f'segment-{i}.mp4'
            run(['ffmpeg','-y','-v','error','-threads','1','-filter_threads','1','-filter_complex_threads','1',
                '-f','concat','-safe','0','-i',str(frames),'-i',str(narration),'-t',f'{length:.3f}','-r','15',
                '-c:v','libx264','-threads','1','-preset','ultrafast','-tune','stillimage','-crf','23','-pix_fmt','yuv420p',
                '-c:a','aac','-b:a','128k','-ar','48000','-af','apad','-movflags','+faststart',str(segment)])
            actual=duration(segment);allcues.extend((s+total,min(t,actual)+total,text) for s,t,text in cues)
            story.append(dict(scene,scene=i,start_seconds=total,duration_seconds=actual));total+=actual;segments.append(segment)
            print(e['slug'],'scene',i,round(actual,2),flush=True)
        concat=a/'concat.txt';concat.write_text(''.join("file '"+str(f)+"'\n" for f in segments))
        target=out/'episode.mp4';run(['ffmpeg','-y','-v','error','-threads','1','-f','concat','-safe','0','-i',str(concat),'-c','copy','-movflags','+faststart',str(target)])
        shutil.copyfile(a/'card-1.png',out/'thumbnail.png')
        srt='\n\n'.join(str(i)+'\n'+stamp(s)+' --> '+stamp(t)+'\n'+text for i,(s,t,text) in enumerate(allcues,1))+'\n'
        (out/'captions.en.srt').write_text(srt)
        (out/'captions.en.vtt').write_text('WEBVTT\n\n'+'\n\n'.join(stamp(s).replace(',','.')+' --> '+stamp(t).replace(',','.')+'\n'+text for s,t,text in allcues)+'\n')
        (p/'storyboard.json').write_text(json.dumps({'title':e['title'],'scenes':story},indent=2))
        (p/'script.md').write_text('\n\n'.join(s['voice'] for s in e['scenes'])+'\n')
        c=catalogue[e['slug']]
        (p/'brief.md').write_text('English portrait explainer for Technology Product.\nAudience: engineers and readers of GERO research.\nNarrator: fictional Alex Vector; preset Microsoft en-US-AndrewNeural, edge-tts 7.2.8, rate -3%.\nOriginal evidence diagrams; no third-party footage or music.\nEvidence category: '+e.get('kind','audit')+'.\n'+e.get('description_boundary','Explains recorded evidence, no new execution or full-model claim.')+'\n')
        source='Report: '+c['gero']+'\nEvidence archive: '+' ; '.join(c.get('zenodo',[]))+'\nPublic artifact: '+c['github_catalog']+'\n'
        if e.get('primary_sources'):source+='Primary sources:\n'+'\n'.join(e['primary_sources'])+'\n'
        ledger='Source ledger — reviewed before narration\n\n'+source+'\n'
        for i,scene in enumerate(e['scenes'],1):ledger+=f'Scene {i}: {scene["voice"]}\nClassification: '+e.get('evidence_class','Recorded result or mathematical explanation from the linked author report; limitations attributed to its test scope. Diagram uses the same reported inputs and values. No new test, novelty or current maintainer acceptance claim.')+'\n\n'
        ledger+='Narration client: https://github.com/rany2/edge-tts . The client is open source; synthesis uses Microsoft\'s online service, not an open local model. Only reviewed public narration text was submitted.\n'
        (p/'sources.md').write_text(ledger)
        summary=e.get('description_summary','A short explanation of the source-pinned numerical evidence in this GERO report.')
        boundary=e.get('description_boundary','This video illustrates recorded library tests. It does not demonstrate customer losses, a security vulnerability, or full-model impact. Exact versions, proposed corrections, prior work and limitations are in the report.')
        description=summary+'\n\n'+source+'\n'+boundary+'\n\nResearch and editorial review: '+e.get('credit','Xamit Kadirbekov / GERO Research')+'. Independent work; no affiliation with the organizations discussed.\nNarration: synthetic English preset Microsoft Andrew Neural via edge-tts. Alex Vector is a fictional narrator. Original diagrams; AI-assisted preparation.\n\n'+e.get('hashtags','#NumericalComputing #SoftwareTesting #Shorts')+'\n'
        (p/'metadata.md').write_text(e['title']+'\n\n'+description)
        (p/'youtube-description.txt').write_text(description)
        sheet=Image.new('RGB',(720,1280),BG)
        for i in range(4):sheet.paste(Image.open(a/f'card-{i+1}.png').resize((360,640)),((i%2)*360,(i//2)*640))
        sheet.save(p/'contact-sheet.jpg')
        run(['ffmpeg','-v','error','-threads','1','-i',str(target),'-map','0','-f','null','-'])
        (out/'render.json').write_text(json.dumps({'signature':signature,'seconds':total,'dimensions':[720,1280],'fps':15,'ffmpeg_threads':1,
            'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'caption_timing':'actual TTS WordBoundary events','full_decode_errors':0,
            'full_playback_verified':False,'visual_review_verified':False,'published':False},indent=2))
        print('RENDERED',e['slug'],round(total,2),flush=True)
if __name__=='__main__':main()

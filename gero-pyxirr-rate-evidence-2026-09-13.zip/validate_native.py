"""Sequential native verification; does not modify old research checkouts."""
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
PYTHON = ROOT / '.venv/bin/python'
env = os.environ.copy()
env.update(PATH='/Users/khamit/Documents/pilory/.rustup/toolchains/stable-aarch64-apple-darwin/bin:' + env['PATH'],
           CARGO_HOME=str(ROOT / '.cargo-home'), CARGO_TARGET_DIR=str(ROOT / 'native-target'),
           CARGO_BUILD_JOBS='1', RUST_TEST_THREADS='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1',
           PYO3_PYTHON=str(PYTHON), PYTHONPATH=str(ROOT / '.venv/lib/python3.12/site-packages'))
commands = []


def run(name, command, cwd=ROOT, extra=None, expected=0):
    e = env.copy()
    e.update(extra or {})
    print(name, flush=True)
    with (ROOT / 'logs' / (name + '.log')).open('w') as log:
        result = subprocess.run([str(x) for x in command], cwd=cwd, env=e,
                                stdout=log, stderr=subprocess.STDOUT)
    commands.append(dict(name=name, command=[str(x) for x in command], cwd=str(cwd),
                         exit_code=result.returncode, expected_exit=expected,
                         environment={k:e[k] for k in ['CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS',
                                                      'PYO3_PYTHON','PYTHONPATH','RUST_TEST_THREADS']}))
    (ROOT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    assert result.returncode == expected, (name, result.returncode, (ROOT/'logs'/(name+'.log')).read_text()[-3000:])


run('reproduce-release', [PYTHON, 'reproduce.py', '--output', 'results/release.json', '--expect', 'affected'])
baseline_wheel, = (ROOT/'wheels/baseline').glob('*.whl')
run('install-native-baseline', [PYTHON, '-m', 'pip', 'install', '--no-deps', '--no-compile', '--upgrade',
                               '--target', ROOT/'env-baseline', baseline_wheel])
run('reproduce-native-baseline', [PYTHON, 'reproduce.py', '--output', 'results/native-baseline.json',
                                '--expect', 'affected'], extra={'PYTHONPATH':str(ROOT/'env-baseline')})
source = ROOT/'pyxirr-corrected'
run('rust-format', ['cargo', 'fmt'], cwd=source)
run('build-corrected', [ROOT/'.venv/bin/maturin', 'build', '--release', '--locked', '--offline',
                       '--interpreter', PYTHON, '--out', ROOT/'wheels/corrected'], cwd=source)
corrected_wheel, = (ROOT/'wheels/corrected').glob('*.whl')
run('install-native-corrected', [PYTHON, '-m', 'pip', 'install', '--no-deps', '--no-compile', '--upgrade',
                                '--target', ROOT/'env-corrected', corrected_wheel])
run('reproduce-native-corrected', [PYTHON, 'reproduce.py', '--output', 'results/native-corrected.json',
                                 '--expect', 'corrected'], extra={'PYTHONPATH':str(ROOT/'env-corrected')})
run('cargo-test-full', ['cargo', 'test', '--release', '--locked', '--', '--test-threads=1'], cwd=source)
original = (source/'src/core/periodic.rs').read_text()
native_tests = ['cargo', 'test', '--release', '--locked', '--test', 'test_periodic']
try:
    mutant = original.replace('!d.is_finite() || d.abs() >= 1e-6', 'd > 1e-6')
    assert mutant != original
    (source/'src/core/periodic.rs').write_text(mutant)
    run('mutation-signed-step', native_tests + ['test_rate_vec_rejects_unconverged_negative_step',
                                              '--', '--test-threads=1'], cwd=source, expected=101)
    start = original.index('    let mut result = g / gp;')
    end = original.index('\n}\n', start)
    mutant = original[:start] + '    g / gp' + original[end:]
    (source/'src/core/periodic.rs').write_text(mutant)
    run('mutation-zero-limit', native_tests + ['test_rate_vec_zero_guess', '--', '--test-threads=1'],
        cwd=source, expected=101)
finally:
    (source/'src/core/periodic.rs').write_text(original)
assert (source/'src/core/periodic.rs').read_text() == original
for name, names in [('mutation-signed-step', ['test_rate_vec_rejects_unconverged_negative_step']),
                    ('mutation-zero-limit', ['test_rate_vec_zero_guess_nonzero_root',
                                             'test_rate_vec_zero_guess_zero_root',
                                             'test_rate_vec_zero_guess_annuity_due',
                                             'test_rate_vec_zero_guess_transient_near_zero'])]:
    log = (ROOT/'logs'/(name+'.log')).read_text()
    assert 'test result: FAILED.' in log and 'error[E' not in log
    assert all(x + ' ... FAILED' in log for x in names)
run('rust-format-check', ['cargo', 'fmt', '--check'], cwd=source)
release = json.loads((ROOT/'results/release.json').read_text())
baseline = json.loads((ROOT/'results/native-baseline.json').read_text())
assert release['counts'] == baseline['counts'], 'Released/native baseline discrepancy'
differences = []
for a, b in zip(release['cases'], baseline['cases'], strict=True):
    if a['observed'] is None or b['observed'] is None:
        assert a['observed'] is b['observed']
    else:
        differences.append(abs(a['observed'] - b['observed']))
        assert math.isclose(a['observed'], b['observed'], rel_tol=1e-10, abs_tol=1e-12)
(ROOT/'results/validation.json').write_text(json.dumps(dict(
    status='passed', released_native_baseline_agree=True,
    maximum_released_native_rate_difference=max(differences), mutation_controls_passed=True,
    candidate_restored_sha256=hashlib.sha256(original.encode()).hexdigest()), indent=2)+'\n')
print('ALL NATIVE VALIDATION GATES PASSED', flush=True)
